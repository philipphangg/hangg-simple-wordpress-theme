<?php
/**
 * The template for displaying the sidebar on the right hand
 *
 * 
 * 
 */
?>
<?php dynamic_sidebar('right_sidebar'); ?>