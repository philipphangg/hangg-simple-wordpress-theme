<?php
/**
 * The template for displaying the footer
 *
 * 
 * 
 */
?>

            </div>
            <!-- end middle wrapper -->
            
            <footer>
                <p>&copy; <?php bloginfo('title');?></p>
            </footer>
        
        </div>
        <!-- end outer wrapper -->
        <?php wp_footer(); ?>
        <!-- Statistik/Analyse-Tool einbauen -->
    </body>
</html>